# Usage Guide

## Configuration

All settings live in `src/iogpConfig.m`.

| Field | Default | Purpose |
|---|---|---|
| `useSampleData` | `true` | `false` reads a real PDF from `data/reports/` |
| `pdfFile` | `""` | PDF file name inside `data/reports/` |
| `pdfUrl` | `""` | Optional direct PDF link, downloaded to `data/reports/` if the file is missing |
| `expectedIncidents`, `expectedFatalities` | `[]` | Totals stated in the report; read from the text if blank |
| `regions`, `settings` | lists | Heading names carried down as columns |
| `fieldLabels` | 10 labels | Labels that delimit each field of a record |
| `dominantShare` | 0.6 | Share of People factors needed for People-dominant (0.4 or less is Process-dominant) |
| `themeRules` | 6 themes | Keyword lists for the keyword classifier |
| `showFigures` | `true` | `false` for headless runs |

## Run on the real IOGP report

1. Download *Safety performance indicators - 2025 data: fatal incident reports* from the IOGP bookstore (https://www.iogp.org/bookstore/).
2. Save the PDF in `data/reports/`.
3. Run:

```matlab
cfg = iogpConfig();
cfg.useSampleData = false;
cfg.pdfFile = "fatal_incident_reports_2025.pdf";
cfg.expectedIncidents = 40;
cfg.expectedFatalities = 0;
runIOGPPipeline(cfg);
```

Set the expected totals to the numbers printed in the report. The parser stops with a warning if the parsed totals differ.

`extractFileText` can change page layout, headings, and bullets. If the totals do not match, inspect the text with
`txt = loadReport(cfg); disp(extractBefore(txt, 3000))` and adjust `regions`, `settings`, `fieldLabels`, or the bullet
pattern in `src/parseCausalFactors.m`. The same applies to other years, whose layout varies.

## Outputs in `results/`

| File | Content |
|---|---|
| `incidents.csv` | One row per incident with all fields, attribution counts and labels, and keyword prediction |
| `keyword_errors.csv` | Incidents where the keyword theme differs from the reported CAUSE |
| `figure_captions.csv` | One-sentence claim for each figure |
| `fig01` to `fig09` | Word cloud, top words, word clouds by cause, fatalities by cause and activity, heatmap, geobubble map, onshore versus offshore, confusion chart, People versus Process |
| `report.md` | Totals check, figures with claims, keyword errors, attribution summary, confidence discussion |

## Live Script submission

Open `main.m` in the Editor and use Save As to create `main.mlx`, run it, then Save > Export to PDF or HTML.

## Tests

```matlab
runtests("tests")
```

## Not included

The advanced tracks (topic models, supervised models, LLM extraction, hierarchy-of-controls analysis, lessons-learned app) and
the multi-year extension are not part of this repository.
