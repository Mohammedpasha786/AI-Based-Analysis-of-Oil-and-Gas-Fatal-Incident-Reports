projectRoot = fileparts(mfilename("fullpath"));
addpath(fullfile(projectRoot, "src"));

cfg = iogpConfig();

results = runIOGPPipeline(cfg);

disp(results.Summary)
fprintf("Report: %s\n", fullfile(cfg.resultsDir, "report.md"));
