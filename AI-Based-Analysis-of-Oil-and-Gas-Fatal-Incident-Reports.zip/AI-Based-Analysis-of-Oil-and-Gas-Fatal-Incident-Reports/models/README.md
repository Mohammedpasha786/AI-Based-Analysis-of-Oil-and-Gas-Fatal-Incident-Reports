# Models

The basic workflow trains no model: it uses keyword rules (`src/iogpConfig.m`, `themeRules`) and counting.
This folder is reserved for trained classifiers or embeddings if the advanced tracks are added.
